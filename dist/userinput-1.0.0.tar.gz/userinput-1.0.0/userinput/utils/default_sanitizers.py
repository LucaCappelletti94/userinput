default_sanitizers = {
    "human_bool": lambda x: x.lower() in ["yes", "y", "true"]
}