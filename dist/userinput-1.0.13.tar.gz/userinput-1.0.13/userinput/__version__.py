"""Current version of package userinput"""
__version__ = "1.0.13"